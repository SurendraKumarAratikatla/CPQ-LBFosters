function ZTHR_PRD_HIERARCHY(input) { 
    var log = sap.log();
    var jsonInput = JSON.parse(input);
    var cpq_TH_PIPE_OD, cpq_TH_PIPE_WALL_THICKNESS,cpq_TH_PIPE_TYPE,cpq_TH_THREAD_TYPE, cpq_TH_PIPE_END, cpq_H_PRODH;
    var value1_p1 = 0.0;
    var value2_p1 = 0.0;
    var value3_p1 = 0.0;
    var value1_num = 0.0;
    var value2_num = 0.0;
    var value3_num = 0.0;
    
    try {
        cpq_TH_PIPE_OD = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'TH_PIPE_OD');
        cpq_H_PRODH = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'TH_PRODH');
        // cps_width = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_WIDTH');
        // cps_length = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_LENGTH');
        // cps_dynamicDesc = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_CUSTOM_TEXT');
    } catch (error) {
        // An exception can occur if no data has been provided
        log.error('Error: incomplete input data');
        throw new Error('Incomplete input');
    }
    
    if (typeof cpq_TH_PIPE_OD === 'undefined') { 
        // Exception handling: unexpected data input
		log.error('Error: incomplete input data - missing (one of) required input data');
        throw new Error('Incomplete input');
    }
    
    // CXT_THICKNESS
    const pipeOdfeatures = cpq_TH_PIPE_OD.values;
    var pipeOdVal = [...pipeOdfeatures]
    var value1p = pipeOdVal.toString();
    const features = cpq_H_PRODH.values;
    var descConds = [...features];
    log.debug('TH_PIPE_OD descConds cpq_H_PRODH------------>' + descConds);
    descConds.push('23 X 34 X 45');

    
    // // Prepare and return
    cpq_H_PRODH.values = descConds;
    
    return JSON.stringify({ type: 'vfun', vfunOutput: { result: true, fnArgs: [ cpq_H_PRODH ] } });
}