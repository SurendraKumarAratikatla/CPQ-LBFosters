function ZCXT_LAGGING_TEXT(input) { 
    var log = sap.log();
    var jsonInput = JSON.parse(input);

    var cps_drying_add_features, cps_varcond,cps_length,cps_dynamicDesc;
    
    try {
        cps_drying_add_features = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_THICKNESS');
        cps_varcond = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_WIDTH');
        cps_length = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_LENGTH');
        cps_dynamicDesc = jsonInput.vfunInput.fnArgs.find(({ id }) => id === 'CXT_CUSTOM_TEXT');
    } catch (error) {
        // An exception can occur if no fnArgs has been provided
        log.error('Error: incomplete input data - no fnArgs provided');
        throw new Error('Incomplete input');
    }
    
    if (typeof cps_drying_add_features === 'undefined' ||
        typeof cps_varcond === 'undefined') { 
        // Exception handling: unexpected fnArgs input
		log.error('Error: incomplete input data - missing (one of) CPS_DRYING_ADD_FEATURES/CPS_VARCOND');
        throw new Error('Incomplete input');
    }
    
    // Copy the values of CPS_DRYING_ADD_FEATURES to CPS_VARCOND
    const features = cps_dynamicDesc.values;
    var varconds = [...features];
    log.debug('CXT_THICKNESS varconds cps_dynamicDesc------------>' + varconds);
    // log.debug('CXT_WIDTH-->' + cps_varcond);
    // log.debug('CXT_LENGTH-->' + cps_length);
    // log.debug('CXT_LENGTH-->' + cps_length);
    // // Special case: if 'SIF' and 'LIP', add 'SIFLIP_DISCOUNT'
    // if (features.includes('SIF') && features.includes('LIP')) {
    //     varconds.push('SIFLIP_DISCOUNT');
    // }
    
    // // Special case: if > 3 features, add 'MANY_FEATURE_DISCOUNT'
    // if (features.length > 3) {
    //     varconds.push('MANY_FEATURE_DISCOUNT');
    // }
    
    varconds.push('8.00 in X 24.0 in X 45.00 in');


    // // Prepare and return
    cps_dynamicDesc.values = varconds;
	
	// log.debug('Calculated VARCONDS' + cps_dynamicDesc.values);
    
    return JSON.stringify({ type: 'vfun', vfunOutput: { result: true, fnArgs: [ cps_dynamicDesc ] } });
}